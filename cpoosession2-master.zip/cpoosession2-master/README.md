Run : gradle build to compile

The test class is src/test/java/org/exec/TaskExecutorTest

The two main of the examples projects are : 
- src/main/java/org/devWork/Main
- src/main/java/org/school/Main