package org.devWork.resource;

import org.exec.resource.ResourceAbstract;

public class PcSpecialDevOps extends ResourceAbstract {
    public PcSpecialDevOps() {
        quantity = 1.0;
    }
}
