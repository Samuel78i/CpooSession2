package org.devWork.resource;

import org.exec.resource.HumanRessource;

public class Tester extends HumanRessource {

}
