package org.devWork.resource;

import org.exec.resource.HumanRessource;

public class Developer extends HumanRessource {

}
