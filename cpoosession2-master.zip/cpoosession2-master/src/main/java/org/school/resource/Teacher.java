package org.school.resource;

import org.exec.resource.HumanRessource;

public class Teacher extends HumanRessource {

}
