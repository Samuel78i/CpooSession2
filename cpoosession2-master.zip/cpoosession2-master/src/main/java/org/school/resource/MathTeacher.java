package org.school.resource;

public class MathTeacher extends Teacher {
}
