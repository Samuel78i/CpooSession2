package org.school.resource;

public class EnglishTeacher extends Teacher {
}
