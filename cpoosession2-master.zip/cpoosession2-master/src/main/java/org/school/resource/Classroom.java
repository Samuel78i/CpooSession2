package org.school.resource;

import org.exec.resource.ResourceAbstract;

public class Classroom extends ResourceAbstract {
    public Classroom(double q) {
        quantity = q;
    }
}
