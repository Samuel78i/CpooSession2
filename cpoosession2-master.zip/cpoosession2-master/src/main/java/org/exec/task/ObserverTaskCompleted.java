package org.exec.task;

public interface ObserverTaskCompleted {
    void notifyFinishedTask(Task o);
}
