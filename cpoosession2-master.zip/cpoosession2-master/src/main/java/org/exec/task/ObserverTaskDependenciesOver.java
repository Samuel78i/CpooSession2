package org.exec.task;

public interface ObserverTaskDependenciesOver {
    void notifyTaskDependenciesOver(Task o);
}
