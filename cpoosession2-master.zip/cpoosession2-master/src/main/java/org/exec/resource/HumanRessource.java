package org.exec.resource;

public class HumanRessource extends ResourceAbstract {
    public HumanRessource() {
        quantity = 1.;
    }

}
