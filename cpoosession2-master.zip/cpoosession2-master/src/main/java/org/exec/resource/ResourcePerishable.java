package org.exec.resource;

public interface ResourcePerishable extends Resource {
}
